package com.book.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.book.bean.Book;
import com.book.exception.IDException;
import com.book.exception.NotFoundException;
import com.book.service.IBookService;


@RestController
public class BookController {
	@Autowired
	IBookService bookservice;
	


	@RequestMapping(value="/byauthor/{author}")
	 public List<Book> findByAuthor(@PathVariable String author ){
	return bookservice.findByAuthor(author);
}
	@RequestMapping(value="/bybookid/id")
	public Book findByBookID(@RequestParam  int id) throws NotFoundException
	{
		return bookservice.findByBookID(id);
		
	}
	@RequestMapping(value = "/newbook", method = RequestMethod.POST)
    public boolean addBook(@RequestBody Book book) throws IDException {
        return bookservice.addBook(book);
    }
	
}
