package com.book.exception;

public class IDException extends Exception {
	public IDException()
	{
		super();
	}
	public IDException(String msg)
	{
		super(msg);
	}

}
