package com.book.exception;

public class NotFoundException extends Exception {
	public  NotFoundException()
	{
		super();
	}
	public  NotFoundException(String msg)
	{
		super(msg);
	}


}
